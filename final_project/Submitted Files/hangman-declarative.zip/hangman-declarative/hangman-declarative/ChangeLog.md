# Changelog for hangman-declarative

## Unreleased changes
